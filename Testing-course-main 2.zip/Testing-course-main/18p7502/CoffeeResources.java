package CoffeeMachine.src;

public class CoffeeResources {
	
int water,milk,beans,sugar;
    
       public CoffeeResources(int water, int milk,int beans, int sugar){
        	this.water=water;
            this.milk=milk;
            this.beans=beans;
            this.sugar=sugar;
        }
	

}
